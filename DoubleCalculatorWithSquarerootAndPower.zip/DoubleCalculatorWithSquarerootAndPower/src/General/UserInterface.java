package General;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import calculator.BusinessLogic;

/**
 * <p> Title: TestCharCode. </p>
 * 
 * <p> Description: A component of the Calculator application </p>
 * 
 * <p> Copyright: Lynn Robert Carter © 2017 </p>
 * 
 *  @author Lynn Robert Carter
 * 
 * @version 4.00	2014-10-18 The JavaFX-based GUI implementation of a long integer calculator 
 * 
 *@author @of @additions korada vandana
 *
 *@version 4.1	2019-01-26 The JavaFX-based GUI for the implementation of a calculator
* 
* @version 4.2	2019-02-20  Added new button which has a functionality of Log to calculator.
* 
* @version 4.3 2019-03-22  Added FSM to Double calculator with error message in operand1 and operand2.
* 
*  @version 4.4 2019-04- Added ErrorTermSolution to the DoubleCalculator
*  
*  @version 4.5 2019-05-08 Added Squareroot and Power button to the double calculator
 *
 */

public class UserInterface {
	
	/**********************************************************************************************

	Attributes
	
	**********************************************************************************************/
	
	/* Constants used to parameterize the graphical user interface.  We do not use a layout manager for
	   this application. Rather we manually control the location of each graphical element for exact
	   control of the look and feel. */
	private final double BUTTON_WIDTH = 60;
	private final double BUTTON_OFFSET = BUTTON_WIDTH/2;

	// These are the application values required by the user interface
	private Label label_DoubleCalculatorEnhanced = new Label("Double Calculator With Squareroot And Power");		// Label to display the name of the program
	
	private Label label_Operand1 = new Label("First operand");			// Label for first Operand
	private TextField text_Operand1 = new TextField();					// The text field for first operand
	
	private Label label_Operand2 = new Label("Second operand");			// Label for second operand
	private TextField text_Operand2 = new TextField();					// The text field for second operand
	
	private Label label_Result = new Label("Result");					// Label for Result
	private TextField text_Result = new TextField();					// The text field for Result
	
	private Label label_Operand1ErrorTerm = new Label("Error Term");			// Label for error term of Operand1
	private TextField text_Operand1ErrorTerm = new TextField();				// Text field for error term of Operand1
	
	private Label label_Operand2ErrorTerm = new Label("Error Term");			// Label for error term of Operand2
	private TextField text_Operand2ErrorTerm = new TextField();				// Text field for error term of Operand2
	
	private Label label_ResultErrorTerm = new Label("Error Term");				// Label for error term of Result
	private TextField text_ResultErrorTerm = new TextField();					// Text field for error term of Result
	
	private Label label_ErrorOperand1 = new Label("");               // Label to display a error message 
	
	private Label label_ErrorOperand2 = new Label("");	            // when user tries to perform any function 
	
	private Label label_ErrorResultErrorTerm = new Label("");					// Label to display error message in Result error term
	
	private Label label_PlusminusOperand1 = new Label("\u00b1");	// The plusminus symbol: \u00b1
	private Label label_PlusminusOperand2 = new Label("\u00b1");	// The plusminus symbol: \u00b1
	private Label label_PlusminusResult = new Label("\u00b1");		// The plusminus symbol: \u00b1
	
	private Button button_Additionition = new Button("\u002b");		// The add symbol: \u002b
	private Button button_Subtraction = new Button("\u2212");		// The subtract symbol: \u2212
	private Button button_Multiplication = new Button("\u00D7");	// The multiply symbol: \u00D7
	private Button button_Divisionision = new Button("\u00F7");	    // The divide symbol: \u00F7
	private Button button_log = new Button("log");                 // The log symbol: \log
	private Button button_Sqrt = new Button("\u221A");             // The root symbol: \u221A
	private Button button_power = new Button("x\u207F");          // The POWER symbol: \u207F
	
	private Label label_Operand1err = new Label("");                // Label to display specific 
	private Label label_Operand2err = new Label("");                // error messages for operands
	
	private Label label_Operand1ErrorErrorTerm = new Label("");                // Label to display specific 
	private Label label_Operand2ErrorErrorTerm = new Label("");                // error messages for error terms
	
	private Label label_ErrorResult = new Label("");					// Label to display specific error messages in Result
	
	private TextFlow err1;											// Labels to display error messages for Operand1	 
    private Text operand1ErrPart1 = new Text();                     
    private Text operand1ErrPart2 = new Text();
    
    private TextFlow err2;											// Labels to display error messages for Operand2
    private Text operand2ErrPart1 = new Text();
    private Text operand2ErrPart2 = new Text();
    
    private TextFlow ErrorTerm1;									// Labels to display error messages for Operand1 error term
    private Text errOperand1Part1 = new Text();
    private Text errOperand1Part2 = new Text();
    
    private TextFlow ErrorTerm2;									// Labels to display error messages for Operand2 error term	
    private Text errOperand2xart1 = new Text();
    private Text errOperand2xart2 = new Text();

	
	private double buttonSpace;		// This is the white space between the operator buttons.
	
	/* This is the link to the business logic */
	public BusinessLogic perform = new BusinessLogic();

	
	/**********************************************************************************************

	Constructors
	
	**********************************************************************************************/

	/**********
	 * This method initializes all of the elements of the graphical user interface. These assignments
	 * determine the location, size, font, color, and change and event handlers for each GUI object.
	 */
	public UserInterface(Pane theRoot) {
				
		// There are 7 gaps. Compute the button space accordingly.
		buttonSpace = Calculator.WINDOW_WIDTH / 6;
		
		// Label theScene with the name of the calculator, centered at the top of the pane
		setupLabelUI(label_DoubleCalculatorEnhanced, "Arial", 24, Calculator.WINDOW_WIDTH, Pos.CENTER, 0, 10);
		
		// Label the first operand just above it, left aligned
		setupLabelUI(label_Operand1, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 40);
		
		// Establish the first text input operand field and when anything changes in operand 1,
		// process both fields to ensure that we are ready to perform as soon as possible.
		setupTextUI(text_Operand1, "Arial", 18, Calculator.WINDOW_WIDTH-500, Pos.BASELINE_LEFT, 10, 70, true);
		text_Operand1.textProperty().addListener((observable, oldValue, newValue) -> {setOperand1(); });
		
		// Move focus to the first operand error term operand when the user presses the enter (return) key
		text_Operand1.setOnAction((event) -> { text_Operand1ErrorTerm.requestFocus(); });
		
		// Establish an error message for the first operand just above it with, left aligned
		setupLabelUI(label_ErrorOperand1, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 180, 45);
		label_ErrorOperand1.setTextFill(Color.RED);
				
		//Bottom proper error message for Operand 1
		label_Operand1err.setTextFill(Color.RED);
		label_Operand1err.setAlignment(Pos.BASELINE_RIGHT);
		setupLabelUI(label_Operand1err, "Arial", 14,  
						Calculator.WINDOW_WIDTH-150-10, Pos.BASELINE_LEFT, 22, 128);
		
		// Establish the plus minus between the text fields of first operand and its error term, left aligned
		setupLabelUI(label_PlusminusOperand1, "Arial", 24, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 630, 70);		
		
		// Label the error term first operand just above it, left aligned
		setupLabelUI(label_Operand1ErrorTerm, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 660, 40);
		
		// Move focus to the first operand error term operand when the user presses the enter (return) key
		text_Operand1ErrorTerm.setOnAction((event) -> { text_Operand2.requestFocus(); });
		
		// Establish the error term text input operand field and when anything changes in operand 1,
		// process both fields to ensure that we are ready to perform as soon as possible.
		setupTextUI(text_Operand1ErrorTerm, "Arial", 18, Calculator.WINDOW_WIDTH-700, Pos.BASELINE_LEFT, 660, 70, true);
		text_Operand1ErrorTerm.textProperty().addListener((observable, oldValue, newValue) -> {setOperand1ET(); });	
				
		//Bottom proper error message for Operand 1 Error Term
		label_Operand1ErrorErrorTerm.setTextFill(Color.RED);
		label_Operand1ErrorErrorTerm.setAlignment(Pos.BASELINE_RIGHT);
		setupLabelUI(label_Operand1ErrorErrorTerm, "Arial", 14,  
						Calculator.WINDOW_WIDTH-150-10, Pos.BASELINE_LEFT, 660,128);
						
		// Label the second operand just above it, left aligned
		setupLabelUI(label_Operand2, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 155);
		
		// Establish the second text input operand field and when anything changes in operand 2,
		// process both fields to ensure that we are ready to perform as soon as possible.
		setupTextUI(text_Operand2, "Arial", 18, Calculator.WINDOW_WIDTH-500, Pos.BASELINE_LEFT, 10, 180, true);
		text_Operand2.textProperty().addListener((observable, oldValue, newValue) -> {setOperand2(); });
		
		// Move the focus to the second operand's error term when the user presses the enter (return) key
		text_Operand2.setOnAction((event) -> { text_Operand2ErrorTerm.requestFocus(); });
		
		// Establish an error message for the second operand just above it with, left aligned
		setupLabelUI(label_ErrorOperand2, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 180, 155);
		label_ErrorOperand1.setTextFill(Color.RED);
				
		//Bottom proper error message for Operand 2			
		label_Operand2err.setTextFill(Color.RED);
		label_Operand2err.setAlignment(Pos.BASELINE_RIGHT);
		setupLabelUI(label_Operand2err, "Arial", 14, 
				Calculator.WINDOW_WIDTH-150-10, Pos.BASELINE_LEFT, 22, 233);
		
		// Establish the plus minus sign between the text fields of first operand and its error term, left aligned
		setupLabelUI(label_PlusminusOperand2, "Arial", 24, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 630, 180);
		
		// Label the error term second operand error term just above it, left aligned
		setupLabelUI(label_Operand2ErrorTerm, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 660, 155);
		
		// Establish the error term text input operand field and when anything changes in operand 2,
		// process both fields to ensure that we are ready to perform as soon as possible.
		setupTextUI(text_Operand2ErrorTerm, "Arial", 18, Calculator.WINDOW_WIDTH-700, Pos.BASELINE_LEFT, 660, 180, true);
		text_Operand2ErrorTerm.textProperty().addListener((observable, oldValue, newValue) -> {setOperand2ET(); });
		
		// Move the focus to the result when the user presses the enter (return) key
		text_Operand2ErrorTerm.setOnAction((event) -> { text_Result.requestFocus(); });
		
		//Bottom proper error message for Operand2 Error Term				
		label_Operand2ErrorErrorTerm.setTextFill(Color.RED);
		label_Operand2ErrorErrorTerm.setAlignment(Pos.BASELINE_RIGHT);
		setupLabelUI(label_Operand2ErrorErrorTerm, "Arial", 14, 
				Calculator.WINDOW_WIDTH-150-10, Pos.BASELINE_LEFT, 660,233);
		
		// Label the result just above the result output field, left aligned
		setupLabelUI(label_Result, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 10, 260);
		
		// Establish the result output field.  It is not editable, so the text can be selected and copied, 
		// but it cannot be altered by the user.  The text is left aligned.
		setupTextUI(text_Result, "Arial", 18, Calculator.WINDOW_WIDTH-500, Pos.BASELINE_LEFT, 10, 290, false);
		
		// Label the error result just above the result output field, left aligned
		setupLabelUI(label_ResultErrorTerm, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 660, 260);
				
		// Establish the error result output field.  It is not editable, so the text can be selected and copied, 
		// but it cannot be altered by the user.  The text is left aligned.
		setupTextUI(text_ResultErrorTerm, "Arial", 18, Calculator.WINDOW_WIDTH-700, Pos.BASELINE_LEFT, 660, 290, false);
		
		// Establish the plus minus sign between the text fields of Result and its error term, left aligned
		setupLabelUI(label_PlusminusResult, "Arial", 24, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 630, 290);
		
		// Establish an error message for the result just above it with, left aligned
		setupLabelUI(label_ErrorResult, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 400, 195);
		label_ErrorResult.setTextFill(Color.RED);
		
		// Establish an error message for the result just above it with, left aligned
		setupLabelUI(label_ErrorResultErrorTerm, "Arial", 18, Calculator.WINDOW_WIDTH-10, Pos.BASELINE_LEFT, 660, 195);
		label_ErrorResultErrorTerm.setTextFill(Color.RED);
		
		// Establish the ADD "+" button, position it, and link it to methods to accomplish its work
		setupButtonUI(button_Additionition, "Symbol", 32, BUTTON_WIDTH, Pos.BASELINE_LEFT, 1 * buttonSpace-BUTTON_OFFSET, 350);
		button_Additionition.setOnAction((event) -> { addOperands();});
		
		// Establish the SUB "-" button, position it, and link it to methods to accomplish its work
		setupButtonUI(button_Subtraction, "Symbol", 32, BUTTON_WIDTH, Pos.BASELINE_LEFT, 2 * buttonSpace-BUTTON_OFFSET, 350);
		button_Subtraction.setOnAction((event) -> { subOperands();});
		
		// Establish the MPY "x" button, position it, and link it to methods to accomplish its work
		setupButtonUI(button_Multiplication, "Symbol", 32, BUTTON_WIDTH, Pos.BASELINE_LEFT, 3 * buttonSpace-BUTTON_OFFSET, 350);
		button_Multiplication.setOnAction((event) -> { mpyOperands();});
		
		// Establish the DIV "/" button, position it, and link it to methods to accomplish its work
		setupButtonUI(button_Divisionision, "Symbol", 32, BUTTON_WIDTH, Pos.BASELINE_LEFT, 4 * buttonSpace-BUTTON_OFFSET, 350);
		button_Divisionision.setOnAction((event) -> { divOperands();});
		
		//Establish the Log "Log" button, position it and link to the methods to accomplish its work
		setupButtonUI(button_log, "Symbol", 32, BUTTON_WIDTH, Pos.BASELINE_LEFT, 5 * buttonSpace-BUTTON_OFFSET, 350);
		button_log.setOnAction((event) -> { logOperands(); });
		
		
		// Establish the SQRT "root" button, position it, and link it to methods to accomplish its work
		setupButtonUI(button_Sqrt, "Symbol", 32, BUTTON_WIDTH, Pos.BASELINE_LEFT, 6 * buttonSpace-BUTTON_OFFSET, 350);
		button_Sqrt.setOnAction((event) -> { sqrtOperands();});
		
		// Establish the POWER "x^n" button, position it, and link it to methods to accomplish its work
				setupButtonUI(button_power, "Symbol", 32, BUTTON_WIDTH, Pos.BASELINE_LEFT, 7 * buttonSpace-BUTTON_OFFSET, 350);
				button_power.setOnAction((event) -> { powerOperands();});
		
		
		
		
		// Error Message for the Measured Value for operand 1
				operand1ErrPart1.setFill(Color.BLACK);
			    operand1ErrPart1.setFont(Font.font("Arial", FontPosture.REGULAR, 18));
			    operand1ErrPart2.setFill(Color.GREEN);
			    operand1ErrPart2.setFont(Font.font("Arial", FontPosture.REGULAR, 24));
			    err1 = new TextFlow(operand1ErrPart1, operand1ErrPart2);
				err1.setMinWidth(Calculator.WINDOW_WIDTH-10); 
				err1.setLayoutX(22);  
				err1.setLayoutY(100);
		
		// Error Message for the Measured Value for operand 2
				operand2ErrPart1.setFill(Color.BLACK);
			    operand2ErrPart1.setFont(Font.font("Arial", FontPosture.REGULAR, 18));
			    operand2ErrPart2.setFill(Color.GREEN);
			    operand2ErrPart2.setFont(Font.font("Arial", FontPosture.REGULAR, 24));
			    err2 = new TextFlow(operand2ErrPart1, operand2ErrPart2);
				err2.setMinWidth(Calculator.WINDOW_WIDTH-10); 
				err2.setLayoutX(22);  
				err2.setLayoutY(210);	
				
		// Error Message for the Error Term for operand 1
				errOperand1Part1.setFill(Color.BLACK);
				errOperand1Part1.setFont(Font.font("Arial", FontPosture.REGULAR, 18));
				errOperand1Part2.setFill(Color.GREEN);
				errOperand1Part2.setFont(Font.font("Arial", FontPosture.REGULAR, 24));
				ErrorTerm1 = new TextFlow(errOperand1Part1, errOperand1Part2);
				ErrorTerm1.setMinWidth(Calculator.WINDOW_WIDTH-10);
				ErrorTerm1.setLayoutX(660);
				ErrorTerm1.setLayoutY(100);
				
		// Error Message for the Error Term for operand 2
				errOperand2xart1.setFill(Color.BLACK);
			    errOperand2xart1.setFont(Font.font("Arial", FontPosture.REGULAR, 18));
			    errOperand2xart2.setFill(Color.GREEN);
			    errOperand2xart2.setFont(Font.font("Arial", FontPosture.REGULAR, 24));
			    ErrorTerm2 = new TextFlow(errOperand2xart1, errOperand2xart2);
				// Establish an error message for the second operand error term just above it with, left aligned
				ErrorTerm2.setMinWidth(Calculator.WINDOW_WIDTH-10); 
				ErrorTerm2.setLayoutX(660);  
				ErrorTerm2.setLayoutY(210);
				
		// Place all of the just-initialized GUI elements into the pane
		theRoot.getChildren().addAll(label_DoubleCalculatorEnhanced, label_Operand1, text_Operand1, label_Operand1ErrorTerm, text_Operand1ErrorTerm,
				label_Operand1err, 	label_Operand2, text_Operand2, label_Operand2ErrorTerm, text_Operand2ErrorTerm, label_Operand2err, 
				label_Result, text_Result, label_ResultErrorTerm, text_ResultErrorTerm, label_ErrorResult, button_Additionition, button_Subtraction, button_Multiplication, 
				button_Divisionision,button_log, button_Sqrt,button_power, err1, err2, label_PlusminusOperand1, label_Operand1ErrorErrorTerm, label_Operand2ErrorErrorTerm,
				label_PlusminusOperand2, label_PlusminusResult, ErrorTerm1, ErrorTerm2);
	}
	
	private void powerOperands() {
		// TODO Auto-generated method stub
		if (binaryOperandIssues()) 									
			return;
		String theAnswer = perform.power();						
		label_ErrorResult.setText("");									
		if (theAnswer.length() > 0) {								
			text_Result.setText(theAnswer);							
			label_Result.setText("power");								
		}
		else {														
			text_Result.setText("");													
			label_Result.setText("Result");							
			label_ErrorResult.setText(perform.getResultErrorMessage());	
		}	
	}
	
	/*******
	 * This public methods invokes the methods of Calculator class and generate a specific error
	 * message when the user enters the value of operand1
	 */
	public void message1() {
		String errMessage = CalculatorValue.checkMeasureValue(text_Operand1.getText());
		if (errMessage != "") {
			label_Operand1err.setText(CalculatorValue.measuredValueErrorMessage);
			if (CalculatorValue.measuredValueIndexofError <= -1) return;
			String input = CalculatorValue.measuredValueInput;
			operand1ErrPart1.setText(input.substring(0, CalculatorValue.measuredValueIndexofError));
			operand1ErrPart2.setText("\u21EB");
		}
	}
	
	/*******
	 * This public methods invokes the methods of Calculator class and generate a specific error
	 * message when the user enters the value of operand1 error term
	 */
	private void message3() {
		String errMessage = CalculatorValue.checkErrorTerm(text_Operand1ErrorTerm.getText());
			if (errMessage != "") {
				label_Operand1ErrorErrorTerm.setText(CalculatorValue.errorTermErrorMessage);
				String input = CalculatorValue.errorTermInput;
			if (CalculatorValue.errorTermIndexofError <= -1) return;
				errOperand1Part1.setText(input.substring(0, CalculatorValue.errorTermIndexofError));
				errOperand1Part2.setText("\u21EB");
			}
		}
		
	/*******
	 * This public methods invokes the methods of Calculator class and generate a specific error
	 * message when the user enters the value of operand2 
	 */
	public void message2() {
		String errMessage = CalculatorValue.checkMeasureValue(text_Operand2.getText());
		if (errMessage != "") {
			label_Operand2err.setText(CalculatorValue.measuredValueErrorMessage);
			if (CalculatorValue.measuredValueIndexofError <= -1) return;
			String input = CalculatorValue.measuredValueInput;
			operand2ErrPart1.setText(input.substring(0, CalculatorValue.measuredValueIndexofError));
			operand2ErrPart2.setText("\u21EB");
		}
	}
	
	/*******
	 * This public methods invokes the methods of Calculator class and generate a specific error
	 * message when the user enters the value of operand2 error term
	 */
	
	public void message4() {
		String errMessage = CalculatorValue.checkErrorTerm(text_Operand2ErrorTerm.getText());
			if (errMessage != "") {
			label_Operand2ErrorErrorTerm.setText(CalculatorValue.errorTermErrorMessage);
			if (CalculatorValue.errorTermIndexofError <= -1) return;
			String input = CalculatorValue.errorTermInput;	
			errOperand2xart1.setText(input.substring(0, CalculatorValue.errorTermIndexofError));
			errOperand2xart2.setText("\u21EB");
			}
		}
		
	/**********
	 * Private local method to initialize the standard fields for a label
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y){
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);		
	}
	
	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e){
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);		
		t.setEditable(e);
	}
	
	/**********
	 * Private local method to initialize the standard fields for a button
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y){
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);		
	}	
	
	/**********************************************************************************************

	User Interface Actions
	
	**********************************************************************************************/

	/**********
	 * Private local method to set the value of the first operand given a text value. The method uses the
	 * business logic class to perform the work of checking the string to see it is a valid value and if 
	 * so, saving that value internally for future computations. If there is an error when trying to convert
	 * the string into a value, the called business logic method returns false and actions are taken to
	 * display the error message appropriately.
	 */
	private void setOperand1() {
		text_Result.setText("");							// Any change of an operand probably invalidates
		label_Result.setText("Result");						// the result, so we clear the old result.
		label_ErrorResult.setText("");
		if (perform.setOperand1(text_Operand1.getText())) {	// Set the operand and see if there was an error
			label_Operand1err.setText("");					// If no error, clear this operands error
			operand1ErrPart1.setText("");                   // Clear the first term of error part
			operand1ErrPart2.setText("");                   // Clear the second term of error part
			if (text_Operand2.getText().length() == 0)		// If the other operand is empty, clear its error
				label_Operand2err.setText("");				// as well.
		}
		else 												// If there's a problem with the operand, display
			message1();										// the error message.
	}

	/**********
	 * Private local method to set the value of the first operand's error term given a text value. The method uses the
	 * business logic class to perform the work of checking the string to see it is a valid value and if 
	 * so, saving that value internally for future computations. If there is an error when trying to convert
	 * the string into a value, the called business logic method returns false and actions are taken to
	 * display the error message appropriately.
	 */
	private void setOperand1ET() {		
		if (perform.setOperand1ET(text_Operand1ErrorTerm.getText())) {
		text_ResultErrorTerm.setText("");									// Any change of an operand probably invalidates
		label_ResultErrorTerm.setText("Error Term");					   // the result, so we clear the old result.
		label_ErrorResultErrorTerm.setText("");		                      // Set the operand and see if there was an error
			label_Operand1ErrorErrorTerm.setText("");						 // If no error, clear this operands error
			errOperand1Part1.setText("");						// Clear the first term of error term error part
			errOperand1Part2.setText("");						 // Clear the second term of error term error part
		}
			if (text_Operand2ErrorTerm.getText().length() == 0)				// If the other operand is empty, clear its error
				label_Operand2ErrorErrorTerm.setText("");						// as well.
				message3();											// If there's a problem with the operand, display
	}																// the error message.		
	
	/**********
	 * Private local method to set the value of the second operand given a text value. The logic is exactly the
	 * same as used for the first operand, above.
	 */
	private void setOperand2() {
		text_ResultErrorTerm.setText("");								   // See setOperand1's comments. The logic is the same!
		label_ResultErrorTerm.setText("Result");				
		label_ErrorResultErrorTerm.setText("");
		if (perform.setOperand2(text_Operand2.getText())) {
			label_Operand2err.setText("");
			operand2ErrPart1.setText("");
			operand2ErrPart2.setText("");
			if (text_Operand1.getText().length() == 0)
				label_Operand1err.setText("");
		}
		else
			message2();
	}
	
	/**********
	 * Private local method to set the value of the second operand's error term given a text value. The logic is exactly the
	 * same as used for the first operand, above.
	 */	
	private void setOperand2ET() {									// See Operand 1 Error Term's comments. The logic is the same!
			text_ResultErrorTerm.setText("");					
			label_ResultErrorTerm.setText("Error Term");						
			label_ErrorResultErrorTerm.setText("");
			if (perform.setOperand2ET(text_Operand2ErrorTerm.getText())) {
				label_Operand2ErrorErrorTerm.setText("");				
				errOperand2xart1.setText("");                   
				errOperand2xart2.setText("");                   
			}	
				if (text_Operand1ErrorTerm.getText().length() == 0)	
				label_Operand1ErrorErrorTerm.setText("");							
				message4();										
		}
	
	/**********
	 * This method is called when a binary operation button has been pressed. It assesses if there are issues 
	 * with either of the binary operands or they are not defined. If not return false (there are no issues)
	 * 
	 * @return	True if there are any issues that should keep the calculator from doing its work.
	 */
	
	private boolean binaryOperandIssues() {
		String errorMessage1 = perform.getOperand1ErrorMessage();	// Fetch the error messages, if there are any
		String errorMessage2 = perform.getOperand2ErrorMessage();
		if (errorMessage1.length() > 0) {						    // Check the first.  If the string is not empty
			label_Operand1err.setText(errorMessage1);			    // there's an error message, so display it.
			if (errorMessage2.length() > 0) {					    // Check the second and display it if there is
				label_Operand2err.setText(errorMessage2);		    // and error with the second as well.
				return true;										// Return true when both operands have errors
			}
			else {
				return true;									    // Return true when only the first has an error
			}
		}
		else if (errorMessage2.length() > 0) {					        // No error with the first, so check the second
			label_Operand2err.setText(errorMessage2);			    // operand. If non-empty string, display the error
			return true;										    // message and return true... the second has an error
		}														    // Signal there are issues
		
		// If the code reaches here, neither the first nor the second has an error condition. The following code
		// check to see if the operands are defined.
		if (!perform.getOperand1Defined()) {						// Check to see if the first operand is defined
			label_Operand1err.setText("No value found");			// If not, this is an issue for a binary operator
			if (!perform.getOperand2Defined()) {					// Now check the second operand. It is is also
				label_Operand2err.setText("No value found");		// not defined, then two messages should be displayed
				return true;										// Signal there are issues
			}
			return true;
		} 
		else if (!perform.getOperand2Defined()) {				    // If the first is defined, check the second. Both
			label_Operand2err.setText("No value found");			// operands must be defined for a binary operator.
			return true;											// Signal there are issues
		}
		
		return false;									    // Signal there are no issues with the operands
		}	
	
	/**********
	 * This method is called when an binary operation (expect square root) button has been pressed. It assesses if there are issues 
	 * with either of the binary operands or they are not defined. If not return false (there are no issues)
	 * 
	 * @return	True if there are any issues that should keep the calculator from doing its work.
	 */
	private boolean binaryOperandIssuesE() {
		
		if (label_Operand1ErrorErrorTerm == null) {
			return false;			
		}	
		if (ErrorTerm2 != null) {
			return false;			
		}		
		return true;											    // Signal there are no issues with the operands
	}
	
	/*****************
	 * This private method is to check, if the error term are left empty then this should not effect the wrking 
	 * of calculator. A default value of 0.5 is set in both the error terms
	 */
	
	private void errorTermCheck() {
		if (text_Operand1ErrorTerm.getLength() == 0) {
			text_Operand1ErrorTerm.setText("0.5");
		}
		
		if (text_Operand2ErrorTerm.getLength() == 0) {
			text_Operand2ErrorTerm.setText("0.5");
		}
	}	
	
	/**********
	 * This method is called when an unary operation (expect square root) button has been pressed. It assesses if there are issues 
	 * with either of the unary operands or they are not defined. If not return false (there are no issues)
	 * 
	 * @return	True if there are any issues that should keep the calculator from doing its work.
	 */
	private boolean unaryOperandIssues() {
		String errorMessage1 = perform.getOperand1ErrorMessage();	// Fetch the error messages, if there are any
		String errorMessage2 = perform.getOperand2ErrorMessage();
		if (errorMessage1.length() > 0) {						// Check the first.  If the string is not empty
			label_Operand1err.setText(errorMessage1);			// there's an error message, so display it.
			if (errorMessage2.length() > 0) {					// Check the second and display it if there is
				label_Operand2err.setText(errorMessage2);		// and error with the second as well.
				return true;										// Return true when both operands have errors
			}
			else {
				return true;										// Return true when only the first has an error
			}
		}
		else if (errorMessage2.length() > 0) {					// No error with the first, so check the second
			label_Operand2err.setText(errorMessage2);			// operand. If non-empty string, display the error
			return true;											// message and return true... the second has an error
		}														// Signal there are issues
		
		// If the code reaches here, neither the first nor the second has an error condition. The following code
		// check to see if the operands are defined.
		if (!perform.getOperand1Defined()) {						
			// Check to see if the first operand is defined
			label_Operand1err.setText("No value found");			
			// If not, this is an issue for a binary operator
			if (!perform.getOperand2Defined()) {					
				// Now check the second operand. It is is also
				label_Operand2err.setText("");		
				// not defined, then two messages should be displayed
				return true;										
			}
			return true;
		} else if (!perform.getOperand2Defined()) {				// If the first is defined, check the second. Both
			label_Operand2err.setText("");			// operands must be defined for a binary operator.
			return true;										
		}
		return false;										
	}
	
	/*******************************************************************************************************
	 * This portion of the class defines the actions that take place when the various calculator
	 * buttons (add, subtract, multiply, divide,log, square root and power) are pressed.
	 */

	/**********
	 * This is the add routine
	 * 
	 */
private void addOperands(){
		
		errorTermCheck();
		// Check to see if both operands are defined and valid
		if (binaryOperandIssues() || binaryOperandIssuesE()) {          // If there are issues with the operands, return	
			text_Result.setText("");
			text_ResultErrorTerm.setText("");
			return;			}
												                    // without doing the computation
		
		// If the operands are defined and valid, request the business logic method to do the addition and return the
		// result as a String. If there is a problem with the actual computation, an empty string is returned
		String theAnswer = perform.addition();						             // Call the business logic addition method
		String theAnswerET = perform.errorTerm(); 
		label_ErrorResult.setText("");									         // Reset any result error messages from before
		if (theAnswer.length() > 0) {								             // Check the returned String to see if it is okay
			label_ErrorOperand1.setText("");
			label_ErrorOperand2.setText("");
			text_Result.setText(theAnswer);							             // If okay, display it in the result field and
			text_ResultErrorTerm.setText(theAnswerET);
			label_Result.setText("Sum");								         // change the title of the field to "Sum"
		}
		else {														             // Some error occurred while doing the addition.
			text_Result.setText("");									         // Do not display a result if there is an error.				
			text_ResultErrorTerm.setText("");
			label_Result.setText("Result");							             // Reset the result label if there is an error.
			label_ErrorResult.setText(perform.getResultErrorMessage());	         // Display the error message.
		}
	}

	/**********
	 * This is the subtract routine
	 * 
	 */
	private void subOperands(){
		errorTermCheck();   							// Check to see if both operands are defined and valid
		
	if (binaryOperandIssues() || binaryOperandIssuesE()) {          // If there are issues with the operands, return	
		text_Result.setText("");
		text_ResultErrorTerm.setText("");
		return;			
	}													     // without doing the computation
				
	// If the operands are defined and valid, request the business logic method to do the subtraction and return the
	// result as a String. If there is a problem with the actual computation, an empty string is returned
		String theAnswer = perform.subtraction();						 // Call the business logic subtraction method
		String theAnswerET = perform.errorTerm(); 
		label_ErrorResult.setText("");									     // Reset any result error messages from before
		
	if (theAnswer.length() > 0) {								             // Check the returned String to see if it is okay
		label_ErrorOperand1.setText("");
		label_ErrorOperand2.setText("");
		text_Result.setText(theAnswer);							             // If okay, display it in the result field and
	    text_ResultErrorTerm.setText(theAnswerET);						     // If okay, display it in the result field and
		label_Result.setText("Difference");							 // change the title of the field to "Difference"
	}
		
	else {													     	 // Some error occurred while doing the subtraction.
		text_Result.setText("");									 // Do not display a result if there is an error.				
		text_ResultErrorTerm.setText("");
	    label_Result.setText("Result");						         // Reset the result label if there is an error.
		label_ErrorResult.setText(perform.getResultErrorMessage());	 // Display the error message.
		}
		
	}

	/**********
	 * This is the multiply routine
	 * 
	 */
	private void mpyOperands(){
		errorTermCheck();
		// Check to see if both operands are defined and valid
		if (binaryOperandIssues() || binaryOperandIssuesE()) {          // If there are issues with the operands, return	
			text_Result.setText("");
			text_ResultErrorTerm.setText("");
			return;			}													             // without doing the computation
		
		// If the operands are defined and valid, request the business logic method to do the multiplication and return the
		// result as a String. If there is a problem with the actual computation, an empty string is returned
		String theAnswer = perform.multiplication();				             // Call the business logic multiplication method
		String theAnswerET = perform.errorTerm(); 
		label_ErrorResult.setText("");									         // Reset any result error messages from before
		if (theAnswer.length() > 0) {								             // Check the returned String to see if it is okay
			label_ErrorOperand1.setText("");
			label_ErrorOperand2.setText("");
			text_Result.setText(theAnswer);							             // If okay, display it in the result field and
			text_ResultErrorTerm.setText(theAnswerET);						             // If okay, display it in the result field and
			label_Result.setText("Product");						             // change the title of the field to "Product"
		}
		else {														             // Some error occurred while doing the multiplication.
			text_Result.setText("");								             // Do not display a result if there is an error.				
			label_Result.setText("Result");						                 // Reset the result label if there is an error.
			text_ResultErrorTerm.setText("");
			label_ErrorResult.setText(perform.getResultErrorMessage());	         // Display the error message.
		}  								
	}

	/**********
	 * This is the divide routine.  If the divisor is zero, the divisor is declared to be invalid.
	 * 
	 */
	private void divOperands(){
		errorTermCheck();
		if (binaryOperandIssues() || binaryOperandIssuesE()) {          // If there are issues with the operands, return	
			text_Result.setText("");
			text_ResultErrorTerm.setText("");
			return;			}												             // without doing the computation
		
		double operand2 = Double.parseDouble(text_Operand2.getText());           // Fetching the value of operand2 and saving it in 
		                                                                         // double data type        
		// Check to see if both operands are defined and valid
				
		if (operand2 != 0f ) {                                           // Check if the operand2 is zero or not  
		// 0f defines it for all float values like, 0.0, 0.00 .... etc
		// If the operands are defined and valid, request the business logic method to do the divide and return the
		// result as a String. If there is a problem with the actual computation, an empty string is returned
		String theAnswer = perform.division();		       			 // Call the business logic division method
		String theAnswerET = perform.errorTerm(); 
		label_ErrorResult.setText("");									         // Reset any result error messages from before

		label_ErrorOperand1.setText("");
		label_ErrorOperand2.setText("");
		text_Result.setText(theAnswer);							             // If okay, display it in the result field and
		text_ResultErrorTerm.setText(theAnswerET);	     					 // If okay, display it in the result field and
		label_Result.setText("Division");	    				 // change the title of the field to "Division"
				
				}
		else {	                                                         // Some error occurred while doing the division.
			text_Result.setText("");			   			             // Do not display a result if there is an error.				
			label_Result.setText("Result");						         // Reset the result label if there is an error.
			text_ResultErrorTerm.setText("");
			label_ErrorResult.setText(perform.getResultErrorMessage());    // Display the error message.
			label_ErrorOperand2.setText("Divisor is invalid");             // Display error message if second operand is zero
		}								
	}
	
	private void logOperands() {
		// TODO Auto-generated method stub
		if (binaryOperandIssues()) 									
			return;
		String theAnswer = perform.log();						
		label_ErrorResult.setText("");									
		if (theAnswer.length() > 0) {								
			text_Result.setText(theAnswer);							
			label_Result.setText("log");								
		}
		else {														
			text_Result.setText("");													
			label_Result.setText("Result");							
			label_ErrorResult.setText(perform.getResultErrorMessage());	
		}	
	}
	
	
	
	/**********
	 * This is the square root routine. If a value is entered in operand2 it becomes empty when the result is shown.
	 * 
	 */
	private void sqrtOperands(){
		// Check to see if both operands are defined and valid
		if (unaryOperandIssues());									// If there are issues with the operands, use another if statement to continue the operation
		// If the operands are defined and valid, request the business logic method to do the division and return the
		// result as a String. If there is a problem with the actual computation, an empty string is returned
		// If a is value entered in Operand2, request the business logic method to do the square root of the function
		if (text_Operand2.getLength() != 0)	{
			text_Operand2.setText("");				// Empty the field of Operand2			
			label_Operand2err.setText("Operand2 is not needed");	// Some error will occur while doing the square root
		}
		
		

	String theAnswer = perform.squareroot();		// Call the business logic sqrt method
	String theAnswerET = perform.errorTerm(); 
	label_ErrorResult.setText("");							// Reset any result error messages from before
	if (theAnswer.length() > 0) {								    // Check the returned String to see if it is okay
		label_ErrorOperand1.setText("");
		label_ErrorOperand2.setText("");
		text_Result.setText(theAnswer);							             
		text_ResultErrorTerm.setText(theAnswerET);     					// If okay, display it in the result field and
		label_Result.setText("Square root");	    				 // change the title of the field to "Square root"
	}
	else {	                                                         // Some error occurred while doing the square root.
		text_Result.setText(" ");			   			            // Do not display a result if there is an error.				
		text_ResultErrorTerm.setText("");
		label_Result.setText("Result");						         // Reset the result label if there is an error.
		label_ErrorResult.setText(perform.getResultErrorMessage());    // Display the error message.
	}								
  }
	
}